package com.varsitycollege.number_chart_calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView

class MainActivity : AppCompatActivity() {
    private lateinit var num: EditText
    private lateinit var btnadd : Button
    private lateinit var listview: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        num = findViewById(R.id.num)
        btnadd = findViewById(R.id.btnadd)
        listview = findViewById(R.id.listview)

        val dataList = ArrayList<String>() //to store values
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, dataList)
        listview.adapter = adapter //connects the data to ui

        btnadd.setOnClickListener {
            dataList.clear() // Clear the previous data in the list

            val inputNumber = num.text.toString().toIntOrNull()
            if (inputNumber != null) {
                for (i in 1..12) {
                    val calc = inputNumber.toString() + " x " + (i.toString()) + " = " + (i*inputNumber)
                    dataList.add(calc.toString())
                }

                adapter.notifyDataSetChanged() // updates the listview to display the data
            }
        }
    }
}
